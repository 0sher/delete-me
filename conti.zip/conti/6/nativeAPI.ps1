$Signature = '[DllImport("kernel32.dll")] public static extern bool IsDebuggerPresent();'
$IsDebuggerPresent = Add-Type -MemberDefinition $Signature -Name "Win32IsDebuggerPresent" -Namespace Win32Functions -PassThru
$Result = $IsDebuggerPresent::IsDebuggerPresent()
Write-Output "IsDebuggerPresent: $Result"

$Signature = '[DllImport("kernel32.dll")] public static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);'
$OpenProcess = Add-Type -MemberDefinition $Signature -Name "Win32GetProcess" -Namespace Win32Functions -PassThru
$hProcess = $OpenProcess::OpenProcess(2035711, 0, $args[0])

$Signature = '[DllImport("kernel32.dll")] public static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);'
$TerminateProcess = Add-Type -MemberDefinition $Signature -Name "Win32TerminateProcess" -Namespace Win32Functions -PassThru
$Result = $TerminateProcess::TerminateProcess($hProcess, 0)
Write-Output "Terminate Process: $Result"
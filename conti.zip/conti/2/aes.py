import pyaes
import secrets
import binascii
import random
import os

PATH = r'C:\windows\temp\tmpfile_aes_{0}.txt'
KEY = b'7625e224dc0f0ec91ad28c1ee67b1eb9'
IV = secrets.randbits(256)
LOOPS = 100

def dummy_files():
    for i in range(LOOPS):
        with open(PATH.format(i+1), 'w') as f:
            for i in range(1000):
                f.write(str(random.randint(1,1000)))

def file_read_plain(path):
    with open(path, 'r') as f:
        data = f.read()
    return data

def file_read_cipher(path):
    data = b'';
    with open(path, 'rb') as f:
        data = f.read()
    return data

def aes_encrypt(plaintext):
    aes = pyaes.AESModeOfOperationCTR(KEY, pyaes.Counter(IV))
    ciphertext = aes.encrypt(plaintext)
    return ciphertext

def save_to_file(ciphertext, path):
    with open(path, 'wb') as f:
        f.write(ciphertext)

def aes_decrypt(ciphertext):
    aes = pyaes.AESModeOfOperationCTR(KEY, pyaes.Counter(IV))
    decrypted = aes.decrypt(ciphertext)
    return decrypted

def cleanup(path):
    os.remove(path)

def main():
    dummy_files()

    # Encryption
    for i in range(LOOPS):
        path = PATH.format(i+1)
        plaintext = file_read_plain(path)
        print("Encrypting %s" % path)
        ciphertext = aes_encrypt(plaintext)
        save_to_file(ciphertext, path)

        # Decryption
        ciphertext = file_read_cipher(path)
        print("Decrypting %s" % path)
        plaintext = aes_decrypt(ciphertext)
        save_to_file(plaintext, path)

        cleanup(path)

if __name__ == '__main__':
    main()